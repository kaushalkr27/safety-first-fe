export const SET_IS_LOADING = "SET_IS_LOADING";

export const SET_TOKEN = "SET_TOKEN";