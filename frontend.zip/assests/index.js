export const LOGO = require('./logo.png'); 

export const SMALL_LOGO = require('./small-logo.png'); 

export const GRAPH = require('./grap.png')